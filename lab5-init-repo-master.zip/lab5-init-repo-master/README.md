# cc-lab6-storage
